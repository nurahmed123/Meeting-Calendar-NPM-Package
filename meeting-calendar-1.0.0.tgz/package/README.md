# Meeting Calendar

A simple React component to embed your Arionys Meeting Calendar booking page.

## Installation

```bash
npm install meeting-calendar
```

## Usage

Import the component and pass your `username` as a prop.

```tsx
import React from 'react';
import { MeetingCalendar } from 'meeting-calendar';

const App = () => {
  return (
    <div className="App">
      <h1>Book a Meeting</h1>
      <MeetingCalendar username="06nurahmed" />
    </div>
  );
};

export default App;
```

## Props

| Prop | Type | Description |
| --- | --- | --- |
| `username` | `string` | **Required**. Your Arionys username. |
| ...iframeProps | `IframeHTMLAttributes` | All standard iframe attributes (e.g., `width`, `height`, `className`, `style`) are supported. |

## License

ISC
